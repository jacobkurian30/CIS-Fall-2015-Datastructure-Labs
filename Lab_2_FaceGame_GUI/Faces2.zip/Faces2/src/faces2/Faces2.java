package faces2;

import java.awt.Color;

/**
 *
 * @author rolf
 */
public class Faces2 {

    public static void main(String[] args) {
        int numFaces = 16;
        AbstractFace[] faces = new AbstractFace[numFaces];
        int f = 0;
        for (int row = 20; row < 480; row += 120) {
            for (int col = 20; col < 640; col += 160) {
                if (Math.random() > 0.5) {
                    faces[f++] = new EllipseFace(col,row,100);
                } else {
                    faces[f++] = new BoxFace(col,row,100);
                }
            }
        }
        // We can access the static SimpleGUI using the class-name!
        AbstractFace.sg.setBackgroundColor(new Color(100,24,56));
        AbstractFace.sg.print("POLYMORPHISM at work! All these faces are stored in one array of type AbstractFace[ ].");
    }
}
